//ANDREA VIRAMONTES
//34110
// Analizador Lexico en C++

#include <iostream>
#include <string>
#include <vector>
#include <regex> // Para usar expresiones regulares

// Enumeración de tipos de tokens
enum class TokenType {
    NUMERO,
    CADENA,
    OPARIMETICO,
    OPRELACIONAL,
    IGUAL,
    COMA,
    PARENTESISIZQ,
    PARENTESISDER,
    INICIOPROGRAMA,
    FINPROGRAMA,
    LEER,
    ESCRIBIR,
    SI,
    ENTONCES,
    FINSI,
    MIENTRAS,
    FINMIENTRAS,
    VARIABLE,
    ESPACIO,
    ERROR,
    UNKNOWN
};

// Estructura de un Token
struct Token {
    TokenType type;
    std::string value;
};

// Clase que contiene los patrones de los tokens
class TipoToken {
public:
    TokenType type;
    std::regex pattern;

    TipoToken(TokenType t, const std::string& p) : type(t), pattern(p) {}
};

// Función para clasificar los tokens de entrada
std::vector<Token> lexer(const std::string& input) {
    std::vector<Token> tokens;

    std::vector<TipoToken> tipos = {
        {TokenType::NUMERO, "-?[0-9]+(\\.([0-9]+)?)?"},
        {TokenType::CADENA, "\".*\""},
        {TokenType::OPARIMETICO, "[*/+-]"},
        {TokenType::OPRELACIONAL, "<=|>=|==|<|>|!="},
        {TokenType::IGUAL, "="},
        {TokenType::COMA, ","},
        {TokenType::PARENTESISIZQ, "\\("},
        {TokenType::PARENTESISDER, "\\)"},
        {TokenType::INICIOPROGRAMA, "inicio-programa"},
        {TokenType::FINPROGRAMA, "fin-programa"},
        {TokenType::LEER, "leer"},
        {TokenType::ESCRIBIR, "escribir"},
        {TokenType::SI, "si"},
        {TokenType::ENTONCES, "entonces"},
        {TokenType::FINSI, "fin-si"},
        {TokenType::MIENTRAS, "mientras"},
        {TokenType::FINMIENTRAS, "fin-mientras"},
        {TokenType::VARIABLE, "[a-zA-Z_][a-zA-Z0-9]*"},
        {TokenType::ESPACIO, "[\t\f\r\n]+"},
        {TokenType::ERROR, "^[\t\f\n]+"}
    };

    size_t i = 0;

    while (i < input.length()) {
        bool matched = false;

        for (const auto& tipo : tipos) {
            std::smatch match;
            std::string substr = input.substr(i);

            if (std::regex_search(substr, match, tipo.pattern) && match.position() == 0) {
                tokens.push_back({tipo.type, match.str()});
                i += match.str().length();
                matched = true;
                break;
            }
        }

        if (!matched) {
            // Si no se encuentra un token válido, es un token desconocido
            tokens.push_back({TokenType::UNKNOWN, std::string(1, input[i])});
            i++;
        }
    }

    return tokens;
}

// Función para mostrar el resultado del análisis léxico
void printTokens(const std::vector<Token>& tokens) {
    for (const auto& token : tokens) {
        std::cout << "Token: " << token.value << ", Type: ";
        switch (token.type) {
            case TokenType::NUMERO: std::cout << "NUMERO"; break;
            case TokenType::CADENA: std::cout << "CADENA"; break;
            case TokenType::OPARIMETICO: std::cout << "OPARIMETICO"; break;
            case TokenType::OPRELACIONAL: std::cout << "OPRELACIONAL"; break;
            case TokenType::IGUAL: std::cout << "IGUAL"; break;
            case TokenType::COMA: std::cout << "COMA"; break;
            case TokenType::PARENTESISIZQ: std::cout << "PARENTESISIZQ"; break;
            case TokenType::PARENTESISDER: std::cout << "PARENTESISDER"; break;
            case TokenType::INICIOPROGRAMA: std::cout << "INICIOPROGRAMA"; break;
            case TokenType::FINPROGRAMA: std::cout << "FINPROGRAMA"; break;
            case TokenType::LEER: std::cout << "LEER"; break;
            case TokenType::ESCRIBIR: std::cout << "ESCRIBIR"; break;
            case TokenType::SI: std::cout << "SI"; break;
            case TokenType::ENTONCES: std::cout << "ENTONCES"; break;
            case TokenType::FINSI: std::cout << "FINSI"; break;
            case TokenType::MIENTRAS: std::cout << "MIENTRAS"; break;
            case TokenType::FINMIENTRAS: std::cout << "FINMIENTRAS"; break;
            case TokenType::VARIABLE: std::cout << "VARIABLE"; break;
            case TokenType::ESPACIO: std::cout << "ESPACIO"; break;
            case TokenType::ERROR: std::cout << "ERROR"; break;
            case TokenType::UNKNOWN: std::cout << "UNKNOWN"; break;
        }
        std::cout << std::endl;
    }
}

int main() {
    std::string input;
    std::cout << "Introduce una cadena de entrada para analizar: ";
    std::getline(std::cin, input);

    std::vector<Token> tokens = lexer(input);
    printTokens(tokens);

    return 0;
}

